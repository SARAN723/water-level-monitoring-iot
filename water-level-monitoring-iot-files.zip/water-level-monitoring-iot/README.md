# Water Level Monitoring System Using Arduino Uno

## Project overview
This project reads an analog water-level sensor and displays the sensor reading and a water-status label on a 16x2 I2C LCD.

## Components
- Arduino Uno
- Analog water-level sensor module
- 16x2 LCD with I2C adapter
- Jumper wires
- USB cable

## Wiring

### Water-level sensor
| Sensor pin | Arduino Uno |
|---|---|
| S / SIG | A0 |
| + / VCC | 5V (check the module rating) |
| - / GND | GND |

### I2C LCD
| LCD pin | Arduino Uno |
|---|---|
| GND | GND |
| VCC | 5V |
| SDA | A4 |
| SCL | A5 |

## Working
1. The sensor's electrical output changes when its sensing tracks contact water.
2. Arduino reads the signal using `analogRead(A0)`, returning a value from 0 to 1023.
3. The program labels the reading as Empty, LOW, Medium, or HIGH.
4. The LCD displays the value and status; the Serial Monitor also prints the raw reading.

## Upload instructions
1. Open `water_level_monitor.ino` in Arduino IDE.
2. Install a compatible `LiquidCrystal_I2C` library if needed.
3. Select **Arduino Uno** and the correct port.
4. Upload the sketch.

## Calibration
The thresholds (350 and 510) are examples. Test readings when dry and at different immersion levels, then adjust the thresholds. The displayed status is an estimate, not a calibrated tank-volume percentage.

## IoT limitation
This version monitors locally and does not send data over the internet. Add suitable Wi-Fi hardware and IoT software for remote monitoring.

See `problem_statement_abstract.pdf` for the problem statement and abstract.
